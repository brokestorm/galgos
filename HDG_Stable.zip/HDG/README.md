## HD Generator for WINDOWS

1. To run HD_Generator, you just need to double click the HD_Generator.bat file. This version works in Windows only.

2. Run the command %APPDATA% at the windows search tool, open the folder LOVE and make a shortcut from HD_Generator, so you can access easier the contents from the result.

The program generates a image and a list corresponding to the HD selected, but the results are saved in a foulder at AppData. In later versions, we'll try to create the shortcut :).
