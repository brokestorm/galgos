function love.conf(t)
    t.version = "0.10.2"
	t.identity = "HD_Generator"
	t.window.title = "HD Generator"
end